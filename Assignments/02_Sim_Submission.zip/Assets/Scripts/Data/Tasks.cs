
// An enumeration for a very simple
// state machine used in this example
public enum Task
{
    Idle,
    Move,
    Gather,
    Attack,
    Returning,
    Pathfinding,
    Death
}