using UnityEngine;

public class ResourceSite : MonoBehaviour
{
    [Header("Resource Site Settings")]
    [SerializeField] private float resourceRate = 10f;
    public float ResourceRate
    {
        get => resourceRate;
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
